import numpy as np

X = np.array(([2, 9], [1, 5], [3, 6]), dtype=float)
y = np.array(([92], [86], [89]), dtype=float)

X = X / np.amax(X, axis=0)
y = y / 100

class Neural_Network:
    def __init__(self):
        self.inputSize = 2
        self.outputSize = 1
        self.hiddenSize = 3
        self.W1 = np.random.randn(self.inputSize, self.hiddenSize)
        self.W2 = np.random.randn(self.hiddenSize, self.outputSize)

    def forward(self, X):
        self.z2 = self.sigmoid(np.dot(X, self.W1))
        return self.sigmoid(np.dot(self.z2, self.W2))

    def sigmoid(self, s):
        return 1 / (1 + np.exp(-s))

    def sigmoidPrime(self, s):
        return s * (1 - s)

    def backward(self, X, y, o):
        self.o_delta = (y - o) * self.sigmoidPrime(o)
        self.z2_delta = np.dot(self.o_delta, self.W2.T) * self.sigmoidPrime(self.z2)
        self.W1 += np.dot(X.T, self.z2_delta)
        self.W2 += np.dot(self.z2.T, self.o_delta)

    def train(self, X, y):
        self.backward(X, y, self.forward(X))

NN = Neural_Network()
print("\nPredicted Output: \n" + str(NN.forward(X)))
print("\nLoss: \n" + str(np.mean(np.square(y - NN.forward(X)))))
NN.train(X, y)
