import pandas as pd

def find_s(data):
    hypo = ['0', '0', '0', '0', '0', '0']
    for idx, row in data.iterrows():
        if row['Goes'] == 'Yes':
            for i in range(len(hypo)-1):
                if hypo[i] == '0':
                    hypo[i] = row[i]
                elif hypo[i] != row[i]:
                    hypo[i] = '?'
    return hypo

filename = 'data.csv'
data = pd.read_csv(filename)
hypothesis = find_s(data)
print("Final hypothesis:", hypothesis)
