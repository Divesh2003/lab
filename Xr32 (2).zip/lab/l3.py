import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score

data = pd.read_csv("tennisdata.csv")
X = data.drop(columns=["PlayTennis"])
y = data["PlayTennis"]

categorical_columns = ['Outlook', 'Temperature', 'Humidity', 'Windy']
for col in categorical_columns:
    X[col] = pd.factorize(X[col])[0]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

classifier = GaussianNB()
classifier.fit(X_train, y_train)

print("Accuracy is:", accuracy_score(classifier.predict(X_test), y_test))
