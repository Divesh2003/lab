package com.example.lab;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Bitmap bg = Bitmap.createBitmap(720, 1280, Bitmap.Config.ARGB_8888);
        ImageView img = findViewById(R.id.imageView);
        img.setImageBitmap(bg);

        Canvas can = new Canvas(bg);
        Paint pnt = new Paint();
        pnt.setColor(Color.MAGENTA);
        pnt.setTextSize(50);

        can.drawRect(400, 200, 650, 700, pnt);
        can.drawCircle(200, 350, 150, pnt);
        can.drawRect(50, 850, 350, 1150, pnt);
        can.drawLine(520, 850, 520, 1150, pnt);
        can.drawText("This is a text!", 250, 112, pnt);
    }
}
