package com.example.anew;

import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    EditText Rollno,Name;
    String roll, name;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db=openOrCreateDatabase("StudentDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS student(rollno VARCHAR,name VARCHAR);");
        Rollno=findViewById(R.id.Rollno);
        Name=findViewById(R.id.Name);

        findViewById(R.id.Insert).setOnClickListener(v -> {
            loadText();
            db.execSQL(String.format("INSERT INTO student VALUES(\"%s\", \"%s\");", roll, name));
            showMessage("Data Inserted");
            clear();
        });

        findViewById(R.id.Delete).setOnClickListener(v -> {
            loadText();
            db.execSQL(String.format("DELETE FROM student WHERE rollno=\"%s\";", roll));
            showMessage("Data Deleted");
            clear();
        });

        findViewById(R.id.Update).setOnClickListener(v -> {
            loadText();
            db.execSQL(String.format("UPDATE student SET name=%s WHERE rollno=\"%s\";", name, roll));
            showMessage("Data Inserted");
            clear();
        });

        findViewById(R.id.View).setOnClickListener(v -> {
            loadText();
            Cursor c=db.rawQuery(String.format("SELECT * FROM student WHERE rollno=\"%s\"", roll), null);
            if(c.moveToFirst()) {
                showMessage("Student found: " + c.getString(1));
            }else {
                showMessage("Student not found!");
            }
            clear();
        });

        findViewById(R.id.ViewAll).setOnClickListener(v -> {
            loadText();
            Cursor c=db.rawQuery("SELECT * FROM student", null);
            if(c.getCount() == 0) {
                showMessage("No Student found!");
            }else {
                StringBuffer buffer=new StringBuffer();
                while(c.moveToNext()){
                    buffer.append(c.getString(0)+" " + c.getString(1) + "\n");
                }
                showMessage(buffer.toString());
            }
            clear();
        });
    }

    void showMessage(String mes){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setMessage(mes);
        builder.show();
    }
    void loadText(){
        roll = Rollno.getText().toString();
        name = Name.getText().toString();
    }
    void clear(){
        Rollno.setText("");
        Name.setText("");
    }
}
